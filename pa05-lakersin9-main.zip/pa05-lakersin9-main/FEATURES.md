﻿## Section 1: Requirements
- Week View
- Event and Task Creation 
- Commitment Warnings 
- Persistence 

## Section 2: Headlining Features
- Task Queue (pop-up)
- Categories

## Section 3: Power ups
- Quotes & Notes

## Section 4: Quality of Life 
- Custom Themes

## Section 5: Extra Credit
- Splash Screen
- Privacy Lock

 