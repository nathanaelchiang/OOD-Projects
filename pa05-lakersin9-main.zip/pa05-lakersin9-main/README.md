Introducing "Bullet Journal For Me" - the ultimate digital bullet journaling experience!

**Key Features:**

1.  **Customizable Week View:** Create a visually appealing spread resembling a bullet journal with customizable week names. Experience the joy of organizing your week in a familiar format, to face the weeks' challenged head strong.
    
2.  **Events and Tasks Management:** Seamlessly create and manage events and tasks. Specify details such as name, day of the week, start time, duration, and completion status. Effortlessly track your commitments and stay organized.
    
3.  **Save and Open Files:** Preserve your journal's data by saving it to a file. Retrieve and display your previous entries by opening a saved .bujo file. Enjoy the convenience of accessing your journal anytime, anywhere.
    
4.  **Maximum Limits and Warnings:** Set maximum limits for events and tasks per day. Receive helpful warnings when the limits are exceeded, ensuring that you stay within your designated goals. The limits are persisted in your .bujo file for consistent tracking.
    
5.  **Popup with Task Overview:** Simplify your week's commitments with a button displaying all tasks. Get a quick glance at each task's name and completion status, making it easy to manage your to-do list effectively.
    
6.  **Categorize Events and Tasks:** Organize your journal with categories. Assign unique categories to events and tasks, enabling efficient filtering and sorting with the newest font changing technology indicating the category (Listed on the side). Easily create new categories and apply them to your entire week.
    
7.  **Inspirational Quotes and Notes:** Stay motivated and inspired by adding to the dedicated section for quotes, goals, or general notes. Capture your thoughts and reflections within your digital bullet journal.
    
8.  **Customizable Themes:** Personalize your journaling experience with customizable themes. Choose from a variety of colors to edit your week view's background. Create a journal that reflects your unique style and preferences.
    
9.  **Welcome Screen and Authentication:** Enjoy a smooth and secure login experience. To ensure privacy, protect your journal's contents with a password or authentication method of your choice. A welcome splash screen greets you upon entering the correct password.

**For the purposes of the project, the password is currently hard coded to "leKING", hence the gif used as a hint in the background. Password hard coded as a static final variable at the beginning of the Display class in the View package.**  

Elevate your bullet journaling practice with "Bullet Journal For Me" and embrace the perfect blend of creativity, organization, and convenience. Stay on top of your commitments, express yourself, and unlock a world of endless possibilities. Start journaling today!
![image](https://github.com/CS-3500-OOD/pa05-lakersin9/assets/114115754/5afb1a7d-c546-4b69-ab2c-5bf57126e2cf)
![image](https://github.com/CS-3500-OOD/pa05-lakersin9/assets/114115754/b799b500-b339-442a-996e-c4a9c7fcc5e0)

**SOLID Principles:**  
S - Our classes have a single responsibility. For example, the Event & Task classes manage the information of their fields when initiliazed with appropriate getter methods respectively. The primary responsibility of the Event class is to represent an event, which includes storing the event's name, day, start time, duration.
O - The Display class can be considered as open for extension and closed for modification because it implements the necessary methods required by the JavaFX Application class. This allows you to extend and customize the behavior of the application by subclassing the Display class and overriding its methods.  
L - The JournalViewImpl class implements the JournalView interface and provides an implementation for its methods, including the load method. The load method in JournalViewImpl follows the contract defined by the JournalView interface and returns a Scene, as specified in the interface. This ensures that any code that depends on the JournalView interface can work seamlessly with an instance of JournalViewImpl.  
I - Both the Event and Task classes implement the same Abstract Class thus having access to the parent's name, day of the week, and category fields. These classes are not forced to depend on methods they don't need, such as the getStartTime() and getDurationTime() that is specific and only needed in the Event Class.  
D - The ScheduledItem abstract class represents a scheduled item, which can be an event or a task. It has a dependency on the Category class, as it has a member variable of type Category. The ScheduledItem class depends on the abstraction provided by the Category class. By following the Dependency Inversion Principle, the ScheduledItem class depends on abstractions (interfaces or abstract classes) rather than concrete implementations. In this case, the Category class is an abstraction, and the ScheduledItem class depends on it through its member variable and setter method.  

There's always room for improvement/change. This is app becomes perfect when you customize it for yourself.  Some features that could be implemented to further **your** unique experience would be:  
- Making the idea of changing your mind easier and accesible from the week view. Users should be able to edit any aspect of any existing Event or Task from the Week view. This includes name, category, and other field methods implemented. Feature could be extended by using something other than a grid pane for the cell the event/ task is being added to.  
- Another improvement could be a task search bar. Users should be able type to search for any Task. Only Tasks relevant to the search should be shown. Search results should be updated on each key press. Since the total task/events are being tracked and added to an array list, implementing a search aspect wouldn't be too difficult, the highlighting (when scheduled item found) and updating results after every character would be the biggest task.


**Image Attributions:**  
Password Background Image-  https://media.giphy.com/media/xUNd9A8hdodr1rdvO0/giphy.gif  

Splash Screen Background Image-  https://media.giphy.com/media/SJXzadwbexJEAZ9S1B/giphy.gif

