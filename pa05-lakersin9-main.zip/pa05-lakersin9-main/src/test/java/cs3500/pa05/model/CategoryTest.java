package cs3500.pa05.model;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Test the Category Class
 */
public class CategoryTest {

  @Test
  public void testGetName() {
    Category category = new Category("Holiday", "Red");
    assertEquals("Holiday", category.getName());
  }

  @Test
  public void testGetColor() {
    Category category = new Category("Personal", "Red");
    assertEquals("Red", category.getColor());
  }

  @Test
  public void testToString() {
    Category category = new Category("LeGlorious King", "Red");
    assertEquals("LeGlorious King", category.toString());
  }
}