package cs3500.pa05.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Test the Task Class
 */
public class TaskTest {

  @Test
  public void testGetName() {
    Task task = new Task("Test Task", "Monday");
    assertEquals("Test Task", task.getName());
  }

  @Test
  public void testGetDay() {
    Task task = new Task("Test Task", "Monday");
    assertEquals("Monday", task.getDay());
  }

  @Test
  public void testGetComplete() {
    Task task = new Task("Test Task", "Monday");
    assertFalse(task.getComplete());
  }

  @Test
  public void testSetComplete() {
    Task task = new Task("Test Task", "Monday");
    task.setComplete(true);
    assertTrue(task.getComplete());
  }

  @Test
  public void testSetCategory() {
    Task task = new Task("Test Task", "Monday");
    Category category = new Category("Test Category", "Red");
    task.setCategory(category);
    assertEquals(category, task.getCategory());
  }

  @Test
  public void testToString() {
    Task task = new Task("Test Task", "Monday");
    assertEquals("Test Task\t\t false", task.toString());
  }
}