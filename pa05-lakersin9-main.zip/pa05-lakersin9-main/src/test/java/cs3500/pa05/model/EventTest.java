package cs3500.pa05.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Test the Event Class
 */
public class EventTest {

  @Test
  public void testGetName() {
    Event event = new Event("Father's Day", "Monday", "10:00", "1 hour");
    assertEquals("Father's Day", event.getName());
  }

  @Test
  public void testGetDay() {
    Event event = new Event("New One Piece episode", "Monday", "10:00", "1 hour");
    assertEquals("Monday", event.getDay());
  }

  @Test
  public void testGetStartTime() {
    Event event = new Event("Basketball Tournament", "Monday", "10:00", "1 hour");
    assertEquals("10:00", event.getStartTime());
  }

  @Test
  public void testGetDuration() {
    Event event = new Event("Club meeting", "Monday", "10:00", "1 hour");
    assertEquals("1 hour", event.getDuration());
  }

  @Test
  public void testSetCategory() {
    Event event = new Event("Watch Spider Man", "Monday", "10:00", "1 hour");
    Category category = new Category("Personal", "Red");
    event.setCategory(category);
    assertEquals(category, event.getCategory());
  }
}