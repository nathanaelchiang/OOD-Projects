package cs3500.pa05.view;

import cs3500.pa05.controller.JournalController;
import cs3500.pa05.controller.JournalControllerImpl;
import java.io.File;
import java.util.Optional;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

/**
 * Creates the display of all stages leading to the week view
 */
public class Display extends Application {

  private static final String PASSWORD = "leKING";


  @Override
  public void start(Stage stage) {
    showLoginScreen(stage);
  }

  private void showLoginScreen(Stage stage) {
    // Create the login screen layout
    VBox loginLayout = new VBox(20);
    loginLayout.setPadding(new Insets(20));
    loginLayout.setAlignment(Pos.CENTER);

    // Add password label and field
    Label passwordLabel = new Label("Enter Password:");
    passwordLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: orange;");
    PasswordField passwordField = new PasswordField();

    // Add login button
    Button loginButton = new Button("Login");
    loginButton.setOnAction(event -> {
      String enteredPassword = passwordField.getText();
      if (enteredPassword.equals(PASSWORD)) {
        showWelcomeScreen(stage);
      } else {
        passwordField.clear();
        passwordField.requestFocus();
      }
    });

    // Add components to login layout
    loginLayout.getChildren().addAll(passwordLabel, passwordField, loginButton);

    // Create the stack pane and set the login layout as the top element
    StackPane stackPane = new StackPane();
    stackPane.getChildren().add(loginLayout);

    // Load the background GIF image and create an ImageView
    Image backgroundImage = new Image(
        getClass().getResourceAsStream("/leGloriousKing.gif")
    );
    ImageView backgroundImageView = new ImageView(backgroundImage);

    // Set the background image view as the bottom element in the stack pane
    stackPane.getChildren().add(0, backgroundImageView);


    // Create the scene using the stack pane as the root
    Scene loginScene = new Scene(stackPane, 300, 200);

    // Set the login screen as the primary stage's scene
    stage.setScene(loginScene);
    stage.setTitle("Login");
    stage.show();
  }

  private void showWelcomeScreen(Stage stage) {

    // Create the welcome screen layout
    StackPane welcomeLayout = new StackPane();
    welcomeLayout.setPadding(new Insets(20));

    // Add the GIF image background
    Image backgroundImage = new Image(
        getClass().getResourceAsStream("/splash.gif")
    );

    ImageView backgroundImageView = new ImageView(backgroundImage);
    welcomeLayout.getChildren().add(backgroundImageView);

    // Add welcome message label
    Label welcomeLabel = new Label("  Welcome\n        to \n       the \nJournal App!");
    welcomeLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
    welcomeLabel.setTextFill(Color.WHITE);

    welcomeLayout.getChildren().add(welcomeLabel);

    // Center alignment for the label
    StackPane.setAlignment(welcomeLabel, Pos.CENTER);

    // Create the scene for the welcome screen
    Scene welcomeScene = new Scene(welcomeLayout, 300, 400);

    // Set the welcome screen as the primary stage's scene
    stage.setScene(welcomeScene);
    stage.setTitle("Welcome");
    stage.show();

    // Wait for 2 seconds using a Timeline
    Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), event -> {
      showWeekView(stage);
    }));
    timeline.play();
  }

  private void showWeekView(Stage stage) {
    // Create the JournalController and JournalView
    JournalController jc = new JournalControllerImpl();
    JournalView jv = new JournalViewImpl(jc);

    try {
      stage.setScene(jv.load());
      stage.setTitle("Journal");
      jc.run();
      stage.show();
    } catch (IllegalArgumentException exc) {
      System.err.println("Unable to load GUI.");
    }
  }



}
