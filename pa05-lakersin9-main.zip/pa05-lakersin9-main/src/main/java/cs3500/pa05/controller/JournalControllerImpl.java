package cs3500.pa05.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cs3500.pa05.model.Category;
import cs3500.pa05.model.DayJson;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.Task;
import cs3500.pa05.model.WeekJson;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import org.controlsfx.control.spreadsheet.Grid;

/**
 * Represents JournalControllerImpl that implements the Journal Controller
 */
public class JournalControllerImpl implements JournalController {
  @FXML
  private HBox weekViewHbox;
  @FXML
  private VBox weekViewVbox;
  @FXML
  private ColorPicker colorPicker;
  @FXML
  private Button buttonEvent;
  @FXML
  private Button buttonTask;
  @FXML
  private GridPane gridpane;
  @FXML
  private Button buttonCategory;
  @FXML
  private Button buttonEventLimit;
  @FXML
  private Button buttonTaskLimit;
  @FXML
  private Button buttonTaskQueue;
  @FXML
  private TextArea textAreaNote;
  @FXML
  private Button buttonSaveNote;
  @FXML
  private Label labelTotalEvents;
  @FXML
  private Label labelTotalTasks;
  @FXML
  private ProgressBar completedProgressBar;
  @FXML
  private Label labelCompletedStatus;
  @FXML
  private Button buttonSave;

  // Sunday's stats
  @FXML
  private ProgressBar sundayProgressBar;
  @FXML
  private Label sundayTaskCountLabel;

  // Monday's stats
  @FXML
  private ProgressBar mondayProgressBar;
  @FXML
  private Label mondayTaskCountLabel;

  // Tuesday's stats
  @FXML
  private ProgressBar tuesdayProgressBar;
  @FXML
  private Label tuesdayTaskCountLabel;

  // Wednesday's stats
  @FXML
  private ProgressBar wednesdayProgressBar;
  @FXML
  private Label wednesdayTaskCountLabel;

  // Thursday's stats
  @FXML
  private ProgressBar thursdayProgressBar;
  @FXML
  private Label thursdayTaskCountLabel;

  // Friday's stats
  @FXML
  private ProgressBar fridayProgressBar;
  @FXML
  private Label fridayTaskCountLabel;

  // Saturday's stats
  @FXML
  private ProgressBar saturdayProgressBar;
  @FXML
  private Label saturdayTaskCountLabel;

  private String savedQuote;

  private List<Category> categoryList;

  private List<Task> taskList;
  private List<Task> monTaskList;
  private List<Task> tuesTaskList;
  private List<Task> wedTaskList;
  private List<Task> thursTaskList;
  private List<Task> friTaskList;
  private List<Task> satTaskList;
  private List<Task> sunTaskList;
  private List<Event> monEventList;
  private List<Event> tuesEventList;
  private List<Event> wedEventList;
  private List<Event> thursEventList;
  private List<Event> friEventList;
  private List<Event> satEventList;
  private List<Event> sunEventList;

  private List<Event> eventList;
  private List<List<Event>> completeEventList;
  private List<List<Task>> completeTaskList;
  private int maxEvents;
  private int maxTasks;
  private String filePath;
  @FXML
  private Button buttonOpen;

  /**
   * Constructs a JournalControllerImpl
   */
  public JournalControllerImpl() {
    this.categoryList = new ArrayList<>();
    this.taskList = new ArrayList<>();
    this.sunTaskList = new ArrayList<>();
    this.monTaskList = new ArrayList<>();
    this.tuesTaskList = new ArrayList<>();
    this.wedTaskList = new ArrayList<>();
    this.thursTaskList = new ArrayList<>();
    this.friTaskList = new ArrayList<>();
    this.satTaskList = new ArrayList<>();
    this.sunEventList = new ArrayList<>();
    this.monEventList = new ArrayList<>();
    this.tuesEventList = new ArrayList<>();
    this.wedEventList = new ArrayList<>();
    this.thursEventList = new ArrayList<>();
    this.friEventList = new ArrayList<>();
    this.satEventList = new ArrayList<>();
    this.eventList = new ArrayList<>();
    this.completeEventList = new ArrayList<>(Arrays.asList(sunEventList, monEventList,
        tuesEventList, wedEventList, thursEventList, friEventList, satEventList));
    this.completeTaskList = new ArrayList<>(Arrays.asList(sunTaskList, monTaskList,
        tuesTaskList, wedTaskList, thursTaskList, friTaskList, satTaskList));
    maxEvents = -1;
    maxTasks = -1;
  }

  /**
   * Sets up the event handlers for various buttons and controls in the application.
   *
   * @throws IllegalStateException if the application is in an invalid state
   */
  @FXML
  public void run() throws IllegalStateException {
    buttonEvent.setOnAction(event -> handleEvent());
    buttonTask.setOnAction(event -> handleTask());
    buttonTaskQueue.setOnAction(event -> handleTaskQueue());
    buttonCategory.setOnAction(event -> handleCategory());
    buttonSaveNote.setOnAction(event -> handleSaveNote());
    buttonEventLimit.setOnAction(event -> handleSetLimits(0));
    buttonTaskLimit.setOnAction(event -> handleSetLimits(1));
    colorPicker.setOnAction(event -> handleColorChange());
    buttonSave.setOnAction(event -> saveFile());
    buttonOpen.setOnAction(event -> openFile());
  }

  /**
   * Set Limits Number of to Tasks and Events
   *
   * @param num limit number
   */

  @FXML
  private void handleSetLimits(int num) {
    TextField limitTextField = new TextField();

    GridPane gridPane = new GridPane();
    gridPane.setHgap(10);
    gridPane.setVgap(10);
    gridPane.addRow(0, new Label("Limit Per Day:"), limitTextField);

    Dialog<ButtonType> dialog = new Dialog<>();
    dialog.setTitle("Set Limits");
    dialog.setHeaderText(null);
    dialog.getDialogPane().setContent(gridPane);
    dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
    dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
    dialog.getDialogPane().setContent(gridPane);
    dialog.showAndWait().ifPresent(result -> {
      if (result == ButtonType.OK) {
        int limit = Integer.parseInt(limitTextField.getText());
        if (num == 0) {
          maxEvents = limit;
        } else if (num == 1) {
          maxTasks = limit;
        }

      }

    });
  }

  /**
   * Handles creating an event
   */
  @FXML
  private void handleEvent() {
    ComboBox<String> dayComboBox = new ComboBox<>();
    ComboBox<Category> categoryComboBox = new ComboBox<>();
    dayComboBox.getItems().addAll("Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday", "Sunday");
    categoryComboBox.getItems().addAll(categoryList);
    GridPane gridPane = createGridPane();
    TextField nameTextField = new TextField();
    gridPane.addRow(0, new Label("Name:"), nameTextField);
    gridPane.addRow(1, new Label("Day of Week:"), dayComboBox);
    TextField startTimeTextField = new TextField();
    gridPane.addRow(2, new Label("Start Time:"), startTimeTextField);
    TextField durationTextField = new TextField();
    gridPane.addRow(3, new Label("Duration:"), durationTextField);
    gridPane.addRow(4, new Label("Category:"), categoryComboBox);
    Dialog<ButtonType> dialog = createDialog("Event Input", gridPane);
    Optional<ButtonType> result = dialog.showAndWait();
    if (result.isPresent() && result.get() == ButtonType.OK) {
      String name = nameTextField.getText();
      String day = dayComboBox.getValue();
      String startTime = startTimeTextField.getText();
      String duration = durationTextField.getText();
      Category selectedCategory = categoryComboBox.getValue();
      Event event = new Event(name, day, startTime, duration);
      event.setCategory(selectedCategory);
      if ((getEventList(day).size() < maxEvents) || (maxEvents == -1)) {
        eventList.add(event);
        System.out.println("Event created: " + event);
        GridPane eventGridPane = createEvent(assignEvent(day, event));
        ScrollPane scrollPane = new ScrollPane(eventGridPane);
        gridpane.add(scrollPane, assignColumn(day), 1);
      } else {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Reached Maximum Event Limit for the Day");
        alert.setContentText("Please reset the event limit if "
            + "you would like to add more events.");
        alert.showAndWait();
      }
    }
  }

  /**
   * Creates a gridpane
   *
   * @return a gridpane
   */
  @FXML
  private GridPane createGridPane() {
    GridPane gridPane = new GridPane();
    gridPane.setHgap(10);
    gridPane.setVgap(10);
    return gridPane;
  }

  /**
   * Creates a dialog
   *
   * @param name name of dialog
   * @param gridPane gridpane to be created on
   * @return a Dialog
   */

  @FXML
  private Dialog createDialog(String name, GridPane gridPane) {
    Dialog<ButtonType> dialog = new Dialog<>();
    dialog.setTitle(name);
    dialog.setHeaderText(null);
    dialog.getDialogPane().setContent(gridPane);
    dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
    dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
    return dialog;
  }

  /**
   * Actually creates an event on the GridPane
   *
   * @param list list of events
   * @return Gridpane
   */
  @FXML
  private GridPane createEvent(List<Event> list) {
    GridPane categoryGridPane = new GridPane();
    categoryGridPane.setHgap(10);
    categoryGridPane.setVgap(10);
    int row = 1;
    for (Event event : list) {
      Label label =
          new Label(event.getName() + "\n" + event.getStartTime() + "\n" + event.getDuration());
      label.setWrapText(true);
      if (!(event.getCategory() == null)) {
        label.setStyle("-fx-text-fill: " + event.getCategory().getColor() + ";");
      }
      VBox taskVbox = new VBox(10);
      taskVbox.getChildren().add(label);
      categoryGridPane.addRow(row, taskVbox);
      row++;
    }
    return categoryGridPane;
  }

  /**
   * Assigns an event to its assigned list
   *
   * @param day day of week
   * @param event an Event
   * @return List of events
   */
  @FXML
  private List<Event> assignEvent(String day, Event event) {
    if (day.equalsIgnoreCase("Sunday")) {
      sunEventList.add(event);
      return sunEventList;
    } else if (day.equalsIgnoreCase("Monday")) {
      monEventList.add(event);
      return monEventList;
    } else if (day.equalsIgnoreCase("Tuesday")) {
      tuesEventList.add(event);
      return tuesEventList;
    } else if (day.equalsIgnoreCase("Wednesday")) {
      wedEventList.add(event);
      return wedEventList;
    } else if (day.equalsIgnoreCase("Thursday")) {
      thursEventList.add(event);
      return thursEventList;
    } else if (day.equalsIgnoreCase("Friday")) {
      friEventList.add(event);
      return friEventList;
    } else if (day.equalsIgnoreCase("Saturday")) {
      satEventList.add(event);
      return satEventList;
    } else {
      return null;
    }
  }

  /**
   * Assigns a day of week to a number
   *
   * @param day day of week
   * @return number from 1-7
   */
  private int assignColumn(String day) {
    if (day.equalsIgnoreCase("Sunday")) {
      return 1;
    } else if (day.equalsIgnoreCase("Monday")) {
      return 2;
    } else if (day.equalsIgnoreCase("Tuesday")) {
      return 3;
    } else if (day.equalsIgnoreCase("Wednesday")) {
      return 4;
    } else if (day.equalsIgnoreCase("Thursday")) {
      return 5;
    } else if (day.equalsIgnoreCase("Friday")) {
      return 6;
    } else if (day.equalsIgnoreCase("Saturday")) {
      return 7;
    } else {
      return 0;
    }

  }

  /**
   * Handles creating a task
   */
  @FXML
  private void handleTask() {
    ComboBox<String> dayComboBox = new ComboBox<>();
    ComboBox<Category> categoryComboBox = new ComboBox<>();
    dayComboBox.getItems()
        .addAll("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
    categoryComboBox.getItems().addAll(categoryList);
    GridPane gridPane = new GridPane();
    gridPane.setHgap(10);
    gridPane.setVgap(10);
    TextField nameTextField = new TextField();
    gridPane.addRow(0, new Label("Name:"), nameTextField);
    gridPane.addRow(1, new Label("Day of Week:"), dayComboBox);
    gridPane.addRow(2, new Label("Category:"), categoryComboBox);
    Dialog<ButtonType> dialog = createDialog("Task Input", gridPane);
    dialog.getDialogPane().setContent(gridPane);
    dialog.showAndWait().ifPresent(result -> {
      if (result == ButtonType.OK) {
        String name = nameTextField.getText();
        String dayOfWeek = dayComboBox.getValue();
        Category selectedCategory = categoryComboBox.getValue();
        Task task = new Task(name, dayOfWeek);
        task.setCategory(selectedCategory);
        if ((getTaskList(dayOfWeek).size() < maxTasks) || (maxTasks == -1)) {
          taskList.add(task);
          System.out.println("Task created: " + task);
          GridPane taskGridPane = createTask(assignTask(dayOfWeek, task));
          ScrollPane scrollPane = new ScrollPane(taskGridPane);
          gridpane.add(scrollPane, assignColumn(dayOfWeek), 2);
        } else {
          Alert alert = new Alert(Alert.AlertType.WARNING);
          alert.setTitle("Warning");
          alert.setHeaderText("Reached Maximum Task Limit for the Day");
          alert.setContentText("Please reset the task limit if "
              + "you would like to add more tasks.");
          alert.showAndWait();
        }
      }
    });
  }

  /**
   * Gets the list of tasks based on the day of week
   *
   * @param day day of week
   * @return correct list of tasks
   */
  @FXML
  private List<Task> getTaskList(String day) {
    if (day.equalsIgnoreCase("Sunday")) {
      return sunTaskList;
    } else if (day.equalsIgnoreCase("Monday")) {
      return monTaskList;
    } else if (day.equalsIgnoreCase("Tuesday")) {
      return tuesTaskList;
    } else if (day.equalsIgnoreCase("Wednesday")) {
      return wedTaskList;
    } else if (day.equalsIgnoreCase("Thursday")) {
      return thursTaskList;
    } else if (day.equalsIgnoreCase("Friday")) {
      return friTaskList;
    } else if (day.equalsIgnoreCase("Saturday")) {
      return satTaskList;
    } else {
      return null;
    }
  }

  /**
   * Gets the list of events based on the day of week
   *
   * @param day day of week
   * @return correct list of events
   */
  @FXML
  private List<Event> getEventList(String day) {
    if (day.equalsIgnoreCase("Sunday")) {
      return sunEventList;
    } else if (day.equalsIgnoreCase("Monday")) {
      return monEventList;
    } else if (day.equalsIgnoreCase("Tuesday")) {
      return tuesEventList;
    } else if (day.equalsIgnoreCase("Wednesday")) {
      return wedEventList;
    } else if (day.equalsIgnoreCase("Thursday")) {
      return thursEventList;
    } else if (day.equalsIgnoreCase("Friday")) {
      return friEventList;
    } else if (day.equalsIgnoreCase("Saturday")) {
      return satEventList;
    } else {
      return null;
    }
  }


  /**
   * Gets the list of tasks based based on the given task and day of week
   *
   * @param day day of week
   * @param task task
   * @return correct list of tasks
   */
  @FXML
  private List<Task> assignTask(String day, Task task) {
    if (day.equalsIgnoreCase("Sunday")) {
      sunTaskList.add(task);
      return sunTaskList;
    } else if (day.equalsIgnoreCase("Monday")) {
      monTaskList.add(task);
      return monTaskList;
    } else if (day.equalsIgnoreCase("Tuesday")) {
      tuesTaskList.add(task);
      return tuesTaskList;
    } else if (day.equalsIgnoreCase("Wednesday")) {
      wedTaskList.add(task);
      return wedTaskList;
    } else if (day.equalsIgnoreCase("Thursday")) {
      thursTaskList.add(task);
      return thursTaskList;
    } else if (day.equalsIgnoreCase("Friday")) {
      friTaskList.add(task);
      return friTaskList;
    } else if (day.equalsIgnoreCase("Saturday")) {
      satTaskList.add(task);
      return satTaskList;
    } else {
      return null;
    }
  }

  /**
   * Actually creates a task on the GridPane
   *
   * @param list list of tasks
   * @return Gridpane
   */
  @FXML
  private GridPane createTask(List<Task> list) {
    GridPane categoryGridPane = new GridPane();
    categoryGridPane.setHgap(10);
    categoryGridPane.setVgap(10);
    int row = 1;
    for (Task t : list) {
      CheckBox checkBox = new CheckBox();
      checkBox.setWrapText(true);
      checkBox.setText(t.getName());
      if (!(t.getCategory() == null)) {
        checkBox.setStyle("-fx-text-fill: " + t.getCategory().getColor() + ";");
      }
      if (t.getComplete()) {
        checkBox.setSelected(true);
      }
      // Create a new VBox for the task
      VBox taskVbox = new VBox(10);
      taskVbox.getChildren().add(checkBox);
      categoryGridPane.addRow(row, taskVbox);
      row++;
      checkBox.setOnAction(event -> {
        // Set the completion status based on the checkbox
        boolean isComplete = checkBox.isSelected();
        t.setComplete(isComplete);
      });
    }
    return categoryGridPane;
  }

  /**
   * Handles creating a category
   */
  @FXML
  private void handleCategory() {
    ComboBox<String> colorComboBox = new ComboBox<>();
    colorComboBox.getItems().addAll(
        "Red", "Orange", "Yellow", "Green", "Blue", "Purple", "Pink", "Brown", "Teal");
    GridPane gridPane = new GridPane();
    gridPane.setHgap(10);
    gridPane.setVgap(10);
    TextField nameTextField = new TextField();
    gridPane.addRow(0, new Label("Name:"), nameTextField);
    gridPane.addRow(1, new Label("Color:"), colorComboBox);
    Dialog<ButtonType> dialog = createDialog("Category Name", gridPane);
    dialog.getDialogPane().setContent(gridPane);
    GridPane categoryGridPane = createCategory();
    dialog.showAndWait().ifPresent(result -> {
      if (result == ButtonType.OK) {
        String name = nameTextField.getText();
        String color = colorComboBox.getValue();
        Category category = new Category(name, color);
        categoryList.add(category);
        System.out.println("Category created: " + category.getName());
        int row = 1;
        for (Category c : categoryList) {
          Label categoryLabel = new Label(c.getName());
          categoryLabel.setStyle("-fx-text-fill: " + c.getColor() + ";");
          categoryGridPane.addRow(row, categoryLabel);
          row++;
        }
        gridpane.add(categoryGridPane, 0, 2);
      }
    });
  }

  /**
   * Actually creates an category on the GridPane
   *
   * @return Gridpane
   */
  @FXML
  private GridPane createCategory() {
    GridPane categoryGridPane = new GridPane();
    categoryGridPane.setHgap(10);
    categoryGridPane.setVgap(10);
    Label categoriesLabel = new Label("Categories:");
    categoryGridPane.add(categoriesLabel, 0, 0);
    return categoryGridPane;
  }

  /**
   * Implements a task queue
   */
  @FXML
  private void handleTaskQueue() {
    // Create a dialog to display the remaining tasks
    Dialog<ButtonType> dialog = new Dialog<>();
    dialog.setTitle("Task Queue");

    // Create a label for the task and completion status
    Label headerLabel = new Label("Task\t\t\t\tCompletion Status");
    headerLabel.setStyle("-fx-font-weight: bold;");

    // Retrieve the tasks and populate the dialog
    ListView<Task> taskListView = new ListView<>();
    taskListView.getItems().addAll(taskList);

    // Create a VBox to hold the label and task list
    VBox contentPane = new VBox();
    contentPane.getChildren().addAll(headerLabel, taskListView);
    dialog.getDialogPane().setContent(contentPane);

    // Add a close button
    dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);

    // Show the dialog
    dialog.showAndWait();
  }

  /**
   * Saves a note or quote
   */
  @FXML
  private void handleSaveNote() {

    savedQuote = textAreaNote.getText();
    // Check if the note was saved
    System.out.println("Quote saved: " + savedQuote);
  }

  /**
   * Handles the color changer for the background
   */
  @FXML
  private void handleColorChange() {
    Color selectedColor = colorPicker.getValue();
    // Update the background color of the week view with the selected color
    weekViewHbox.setStyle("-fx-background-color: " + toRgbCode(selectedColor) + ";");
    weekViewVbox.setStyle("-fx-background-color: " + toRgbCode(selectedColor) + ";");
  }

  /**
   * toRGB code
   *
   * @param color color
   * @return name of color
   */
  @FXML
  private String toRgbCode(Color color) {
    return String.format("#%02X%02X%02X",
        (int) (color.getRed() * 255),
        (int) (color.getGreen() * 255),
        (int) (color.getBlue() * 255));
  }

  /**
   * Saves a Bujo File
   * Asks user for file the first time and then saves to that file
   */
  @FXML
  public void saveFile() {
    if (filePath == null) {
      TextInputDialog dialog = new TextInputDialog();
      dialog.setTitle("Open File");
      dialog.setHeaderText(null);
      dialog.setContentText("Enter the file path:");

      // Show the dialog and wait for user input
      Optional<String> result = dialog.showAndWait();

      if (result.isPresent()) {
        filePath = result.get();
        File file = new File(filePath);

        if (file.exists() && file.isFile()) {
          writeFile(filePath);
        } else {
          System.out.println("Invalid file path or file does not exist.");
        }
      }
    } else {
      writeFile(filePath);
    }
  }

  /**
   * Writes to a file
   *
   * @param filePath a filepath
   */
  @FXML
  private void writeFile(String filePath) {
    File file = new File(filePath); // Specify the file path
    try {
      FileWriter fileWriter = new FileWriter(file);
      fileWriter.write(handleData().toString());
      fileWriter.close();
      System.out.println("Data saved to file successfully!");
    } catch (IOException e) {
      System.out.println("Error occurred while saving data to file: " + e.getMessage());
    }
  }

  /**
   * Handles the data to be stored
   *
   * @return a JsonNode
   */
  @FXML
  private JsonNode handleData() {
    DayJson sundayJson = new DayJson(sunEventList, sunTaskList);
    DayJson mondayJson = new DayJson(monEventList, monTaskList);
    DayJson tuesdayJson = new DayJson(tuesEventList, tuesTaskList);
    DayJson wednesdayJson = new DayJson(wedEventList, wedTaskList);
    DayJson thursdayJson = new DayJson(thursEventList, thursTaskList);
    DayJson fridayJson = new DayJson(friEventList, friTaskList);
    DayJson saturdayJson = new DayJson(satEventList, satTaskList);

    WeekJson weekJson = new WeekJson(sundayJson, mondayJson, tuesdayJson, wednesdayJson,
        thursdayJson, fridayJson, saturdayJson, savedQuote);

    ObjectMapper mapper = new ObjectMapper();
    return mapper.convertValue(weekJson, JsonNode.class);
  }

  /**
   * Opens a Bujo File
   * Asks user for file the first time and opens that file in the journal
   */
  @FXML
  public void openFile() {
    if (filePath == null) {
      TextInputDialog dialog = new TextInputDialog();
      dialog.setTitle("Open File");
      dialog.setHeaderText(null);
      dialog.setContentText("Enter the file path:");

      // Show the dialog and wait for user input
      Optional<String> result = dialog.showAndWait();

      if (result.isPresent()) {
        filePath = result.get();
        File file = new File(filePath);

        if (file.exists() && file.isFile()) {
          readFile(filePath);
        } else {
          System.out.println("Invalid file path or file does not exist.");
        }
      }
    } else {
      writeFile(filePath);
    }
  }

  /**
   * Reads a bujo file
   *
   * @param filePath filepath
   */
  @FXML
  private void readFile(String filePath) {
    File file = new File(filePath);
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
      StringBuilder content = new StringBuilder();
      String line;
      while ((line = reader.readLine()) != null) {
        content.append(line);
        content.append(System.lineSeparator());
      }
      ObjectMapper objectMapper = new ObjectMapper();
      WeekJson weekJson = objectMapper.readValue(content.toString(), WeekJson.class);
      assignLists(weekJson);
      completeEventList = new ArrayList<>(Arrays.asList(sunEventList, monEventList,
          tuesEventList, wedEventList, thursEventList, friEventList, satEventList));
      completeTaskList = new ArrayList<>(Arrays.asList(sunTaskList, monTaskList,
          tuesTaskList, wedTaskList, thursTaskList, friTaskList, satTaskList));
      int eventCount = 0;
      for (List<Event> list : completeEventList) {
        GridPane eventGridPane = createEvent(list);
        ScrollPane scrollPane = new ScrollPane(eventGridPane);
        eventCount++;
        gridpane.add(scrollPane, eventCount, 1);
      }
      int taskCount = 0;
      for (List<Task> list : completeTaskList) {
        GridPane taskGridPane = createTask(list);
        ScrollPane scrollPane = new ScrollPane(taskGridPane);
        taskCount++;
        gridpane.add(scrollPane, taskCount, 2);
      }
      readCategoryEvent();
      readCategoryTask();
      textAreaNote.setText(weekJson.notes());
      System.out.println("File content:");
      System.out.println(content);
    } catch (IOException e) {
      System.out.println("Error occurred while reading the file: " + e.getMessage());
    }
  }

  /**
   * Reads the categories for events
   */
  private void readCategoryEvent() {
    int row = 1;
    GridPane categoryGridPane = createCategory();
    for (List<Event> list : completeEventList) {
      for (Event event : list) {
        Category c = event.getCategory();
        if (!(c == null)) {
          categoryList.add(c);
          Label categoryLabel = new Label(c.getName());
          categoryLabel.setStyle("-fx-text-fill: " + c.getColor() + ";");
          categoryGridPane.addRow(row, categoryLabel);
          row++;
          gridpane.add(categoryGridPane, 0, 2);
        }
      }
    }
  }

  /**
   * Reads the categories for tasks
   */
  private void readCategoryTask() {
    int row = 1;
    GridPane categoryGridPane = createCategory();
    for (List<Task> list : completeTaskList) {
      for (Task task : list) {
        Category c = task.getCategory();
        if (!(c == null)) {
          categoryList.add(c);
          Label categoryLabel = new Label(c.getName());
          categoryLabel.setStyle("-fx-text-fill: " + c.getColor() + ";");
          categoryGridPane.addRow(row, categoryLabel);
          row++;
          gridpane.add(categoryGridPane, 0, 2);
        }
      }
    }
  }

  /**
   * Assigns the data to its respective list
   *
   * @param weekJson a WeekJson
   */
  @FXML
  public void assignLists(WeekJson weekJson) {
    sunEventList = weekJson.sunday().events();
    sunTaskList = weekJson.sunday().tasks();
    monEventList = weekJson.monday().events();
    monTaskList = weekJson.monday().tasks();
    tuesEventList = weekJson.tuesday().events();
    tuesTaskList = weekJson.tuesday().tasks();
    wedEventList = weekJson.wednesday().events();
    wedTaskList = weekJson.wednesday().tasks();
    thursEventList = weekJson.thursday().events();
    thursTaskList = weekJson.thursday().tasks();
    friEventList = weekJson.friday().events();
    friTaskList = weekJson.friday().tasks();
    satEventList = weekJson.saturday().events();
    satTaskList = weekJson.saturday().tasks();
  }
}