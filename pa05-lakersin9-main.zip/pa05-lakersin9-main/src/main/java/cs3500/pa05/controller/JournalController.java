package cs3500.pa05.controller;

/**
 * Represents the interface for Journal Controller
 */
public interface JournalController {
  void run() throws IllegalStateException;
}
