package cs3500.pa05;

import cs3500.pa05.view.Display;
import javafx.application.Application;

/**
 * Represents the Driver class that runs the entire program
 */
public class Driver {

  public static void main(String[] args) {
    Application.launch(Display.class, args);
  }
}
