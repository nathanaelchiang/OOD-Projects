package cs3500.pa05.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents an event
 */
public class Event {
  private String name;
  private String day;
  private String startTime;
  private String duration;
  private Category category;


  /**
   * Constructs an event
   *
   * @param n name of event
   * @param d day of the event
   * @param st starting time of event
   * @param dur duration of the event
   */
  @JsonCreator
  public Event(@JsonProperty("name") String n, @JsonProperty("day") String d,
               @JsonProperty("startTime") String st, @JsonProperty("duration") String dur) {
    this.name = n;
    this.day = d;
    this.startTime = st;
    this.duration = dur;
  }

  /**
   * Gets name
   *
   * @return name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets day
   *
   * @return day
   */
  public String getDay() {
    return day;
  }

  /**
   * Gets start time
   *
   * @return string
   */
  public String getStartTime() {
    return startTime;
  }

  /**
   * Gets duration
   *
   * @return duration
   */
  public String getDuration() {
    return duration;
  }

  /**
   * Gets category
   *
   * @return category
   */
  public Category getCategory() {
    return category;
  }

  /**
   * Sets category
   */
  public void setCategory(Category category) {
    this.category = category;
  }

}
