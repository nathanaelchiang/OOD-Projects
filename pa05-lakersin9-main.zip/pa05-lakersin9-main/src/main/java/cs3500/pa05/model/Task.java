package cs3500.pa05.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a task
 */
public class Task {

  private String name;
  private String day;
  private Boolean complete;
  private Category category;

  /**
   * Constructs a task
   *
   * @param n name of the task
   * @param d day of the week for task
   */
  @JsonCreator
  public Task(@JsonProperty("name") String n, @JsonProperty("day") String d) {
    this.name = n;
    this.day = d;
    this.complete = false;
  }

  /**
   * Gets name
   *
   * @return string name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets day
   *
   * @return string
   */
  public String getDay() {
    return day;
  }

  /**
   * Gets complete
   *
   * @return true or false
   */
  public boolean getComplete() {
    return complete;
  }

  /**
   * Sets complete
   */
  public void setComplete(boolean status) {
    complete = status;
  }

  /**
   * Gets category
   *
   * @return category
   */
  public Category getCategory() {
    return category;
  }

  /**
   * Sets category
   */
  public void setCategory(Category category) {
    this.category = category;
  }

  @Override
  public String toString() {
    return name + "\t\t " + complete;
  }

}

