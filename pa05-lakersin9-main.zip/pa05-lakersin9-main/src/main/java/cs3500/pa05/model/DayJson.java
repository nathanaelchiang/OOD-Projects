package cs3500.pa05.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.Task;
import java.util.List;

/**
 * Creates a record for the Day
 *
 * @param events the events for the day
 * @param tasks the tasks for the day
 */
public record DayJson(
    @JsonProperty("events") List<Event> events,
    @JsonProperty("tasks") List<Task> tasks
) {
}
