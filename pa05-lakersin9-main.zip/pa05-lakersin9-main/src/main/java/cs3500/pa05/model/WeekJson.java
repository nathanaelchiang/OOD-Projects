package cs3500.pa05.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Creates record for the week
 *
 * @param sunday the day Sunday
 * @param monday the day Monday
 * @param tuesday the day Tuesday
 * @param wednesday the day Wednesday
 * @param thursday the day Thursday
 * @param friday the day Friday
 * @param saturday the day Saturday
 * @param notes the Quotes and Notes from the text area
 */
public record WeekJson(
    @JsonProperty("Sunday") DayJson sunday,
    @JsonProperty("Monday") DayJson monday,
    @JsonProperty("Tuesday") DayJson tuesday,
    @JsonProperty("Wednesday") DayJson wednesday,
    @JsonProperty("Thursday") DayJson thursday,
    @JsonProperty("Friday") DayJson friday,
    @JsonProperty("Saturday") DayJson saturday,
    @JsonProperty("notes") String notes) {
}

