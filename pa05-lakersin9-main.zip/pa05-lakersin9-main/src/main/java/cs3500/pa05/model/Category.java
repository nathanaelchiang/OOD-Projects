package cs3500.pa05.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a Category
 */
public class Category {
  private String name;
  private String color;

  @JsonCreator
  public Category(@JsonProperty("name") String n, @JsonProperty("color") String c) {
    this.name = n;
    this.color = c;
  }

  /**
   * Gets name
   *
   * @return name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets color
   *
   * @return color
   */
  public String getColor() {
    return color;
  }

  /**
   * Overrides toString method
   *
   * @return a string
   */
  @Override
  public String toString() {
    return name;
  }
}
