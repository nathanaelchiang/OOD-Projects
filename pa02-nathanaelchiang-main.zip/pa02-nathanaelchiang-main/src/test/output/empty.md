[[What is the chemical symbol for hydrogen?:::The symbol is H.]]E1
[[What is the chemical symbol for oxygen?:::The symbol is O.]]H2
