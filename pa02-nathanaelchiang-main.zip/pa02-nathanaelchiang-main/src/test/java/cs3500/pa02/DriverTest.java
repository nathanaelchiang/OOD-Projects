package cs3500.pa02;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.junit.jupiter.api.Test;

/**
 * Tests the driver
 */
public class DriverTest {
  /**
   * Tests that after running the driver, the md and sr files are outputted.
   *
   * @throws IOException for any invalid arguments
   */
  @Test
  public void testMain() throws IOException {
    String notesRoot =
        "src/test/pa01test";
    String filename = "filename";
    String created = "created";
    String modified = "modified";
    String outputFilePath =
        "src/test/output/output.md";
    String[] args = {notesRoot, filename, outputFilePath};
    String[] args2 = {notesRoot, modified, outputFilePath};
    Driver.main(args);
    Driver.main(args2);
    Path file = Paths.get(outputFilePath);
    assertTrue(Files.exists(file), outputFilePath);
    String outputSrPath = "src/test/output/output.sr";
    Path file1 = Paths.get(outputSrPath);
    assertTrue(Files.exists(file1), outputSrPath);
  }

  /**
   * Tests the invalid flag exception
   */
  @Test
  public void testException() {
    String notesRoot =
        "src/test/pa01test";
    String invalidFlag = "invalid";
    String outputFilePath =
        "src/test/output/output.md";
    String[] args = {notesRoot, invalidFlag, outputFilePath};
    try {
      Driver.main(args);
    } catch (IllegalArgumentException e) {
      System.out.println("Error");
      assertEquals("Invalid flag.", e.getMessage());
    } catch (IOException e) {
      throw new RuntimeException(e);
    }

  }

  /**
   * Tests the invalid flag exception
   */
  @Test
  public void testException2() {
    String notesRoot =
        "src/test/pa01test2";
    String invalidFlag = "invalid";
    String outputFilePath =
        "src/test/output/output.md";
    String[] args = {notesRoot, invalidFlag, outputFilePath, "2", "5"};
    try {
      Driver.main(args);
    } catch (IllegalArgumentException e) {
      System.out.println("Error");
      assertEquals("Invalid flag.", e.getMessage());
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
}