package cs3500.pa02;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests the FileVisitor class for the markdown files
 */
class FileVisitorTest {
  static final String PA01_DIRECTORY = "src/test/pa01test";

  /**
   * Tests the visitFile function
   *
   * @throws IOException exception
   */
  @BeforeEach
  public void testVisitFile() throws IOException {
    FileVisitor storage = new FileVisitor();

    Path filePath = Path.of(PA01_DIRECTORY + "/arrays.md");
    Path filePath1 = Path.of(PA01_DIRECTORY + "/vectors.md");
    BasicFileAttributes fileAttributes = Files.readAttributes(filePath, BasicFileAttributes.class);
    storage.visitFile(filePath, fileAttributes);
    storage.visitFile(filePath1, fileAttributes);

    ArrayList<String> actualFiles = storage.getList();
    assertEquals(2, actualFiles.size());
    assertEquals("src/test/pa01test/arrays.md", actualFiles.get(0));

    Path nonMdFilePath = Path.of(PA01_DIRECTORY + "/other.txt");
    storage.visitFile(nonMdFilePath, fileAttributes);

    actualFiles = storage.getList();
    assertEquals(2, actualFiles.size());
  }

  /**
   * Tests the getList function
   *
   * @throws IOException exception
   */
  @BeforeEach
  public void testGetList() throws IOException {
    FileVisitor mfv = new FileVisitor();
    Files.walkFileTree(Path.of(PA01_DIRECTORY), mfv);

    ArrayList<Path> expectedFiles = new ArrayList<>();
    expectedFiles.add(Path.of("arrays.md"));
    expectedFiles.add(Path.of("vectors.md"));

    ArrayList<String> actualFiles = mfv.getList();

    //    assertEquals(2, actualFiles.size());
    //    assertArrayEquals(expectedFiles.toArray(), actualFiles.toArray());
  }

  /**
   * Tests the visitFile function
   *
   * @throws IOException exception
   */
  @Test
  public void testVisitFile2() throws IOException {
    Path startingDirectory = Path.of(PA01_DIRECTORY + "/connectLines.md");
    FileVisitor pf = new FileVisitor();

    Files.walkFileTree(startingDirectory, pf);

    ArrayList<String> expectedFiles = new ArrayList<>();

  }

}
