package cs3500.pa02;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * represents tests that process the markdown files
 */
public class ProcessorTest {

  static final String PA01_DIRECTORY = "src/test/pa01test";

  /**
   * Tests generating the study guide
   *
   * @throws FileNotFoundException if file is not found
   */
  @Test
  public void testGenerateStudyGuide() throws FileNotFoundException {
    String stringName = PA01_DIRECTORY + "/arrays.md";
    String stringName2 = PA01_DIRECTORY + "/vectors.md";
    ArrayList<String> listNames = new ArrayList<>();
    listNames.add(stringName);
    listNames.add(stringName2);

    String outputPath = "src/test/output/outputTest.md";

    Processor.generateStudyGuide(listNames, outputPath);

    File outputFile = new File(outputPath);
    Assertions.assertTrue(outputFile.exists());
  }

  /**
   * Tests processing lines of an arrayList of files
   *
   * @throws FileNotFoundException if file not found
   */
  @Test
  public void testProcessLines() throws FileNotFoundException {
    ArrayList<File> inputFiles = new ArrayList<>();
    inputFiles.add(new File(PA01_DIRECTORY + "/arrays.md"));
    inputFiles.add(new File(PA01_DIRECTORY + "/vectors.md"));

    ArrayList<String> output = Processor.processFiles(inputFiles);

  }

  /**
   * Tests connecting the lines of two disconnected lines
   *
   * @throws FileNotFoundException if file is not found
   */
  @Test
  public void testConnectLines() throws FileNotFoundException {

    File inputFile = new File(PA01_DIRECTORY + "/connectLines.md");

    ArrayList<String> output = Processor.connectLines(inputFile);

    List<String> expectedLines = Arrays.asList(
        "# Heading",
        "- Testing a connected line",
        "",
        "- Testing two  disconnected lines"
    );
    assertEquals(expectedLines, output);
  }

  /**
   * Tests getting the important phrases
   */
  @Test
  public void testGetImportantPhrase() {
    String lineWithPhrase = "- This is an [[important phrase]].";
    String lineWithoutPhrase = "- This is a regular line.";
    String lineForSr = "[[What is the chemical symbol for hydrogen?:::The symbol is H.]]";

    String phrase1 = Processor.getImportantPhrase(lineWithPhrase);
    String phrase2 = Processor.getImportantPhrase(lineWithoutPhrase);
    String phrase3 = Processor.getImportantPhrase(lineForSr);

    assertEquals("- important phrase", phrase1);
    assertNull(phrase2);
    assertNull(phrase3);
  }
}


