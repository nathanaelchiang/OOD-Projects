package cs3500.pa02;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import org.junit.jupiter.api.Test;

/**
 * Tests the QuestionViewer class
 */
class QuestionViewerTest {

  /**
   * Tests the checkSrFile method
   */
  @Test
  public void testCheckSrFileValid() {
    String filePath = "sample.sr";

    ByteArrayInputStream inputStream = new ByteArrayInputStream((filePath + "\n").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);
    QuestionViewer.checkSrFile();
    PrintStream originalOut = System.out;
    System.out.flush();
    System.setOut(originalOut);

    String consoleOutput = outputStream.toString();

    assertTrue(consoleOutput.contains("Enter the path of the sr file"));
    assertFalse(consoleOutput.contains("Not a sr file."));
    assertEquals(filePath, QuestionViewer.filePath);
  }

  /**
   * Tests the checkSrFile exception
   */
  @Test
  public void testCheckSrFileError() {
    String filePath = "sample.md";

    ByteArrayInputStream inputStream = new ByteArrayInputStream((filePath + "\n").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);

    try {
      QuestionViewer.checkSrFile();
    } catch (InputMismatchException e) {
      assertEquals("Not a sr file.", e.getMessage());
    }

    PrintStream originalOut = System.out;
    System.out.flush();
    System.setOut(originalOut);

    String consoleOutput = outputStream.toString();

    System.out.println(consoleOutput);
    assertTrue(consoleOutput.contains("Enter the path of the sr file"));

  }

  /**
   * Tests the askNumberOfQuestions method
   */
  @Test
  public void testAskNumberOfQuestions() {
    String userInput = "1";

    ByteArrayInputStream inputStream = new ByteArrayInputStream((userInput + "\n").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);

    QuestionViewer.filePath = "sample.sr";

    QuestionViewer.askNumberOfQuestions();
    PrintStream originalOut = System.out;
    System.out.flush();
    System.setOut(originalOut);

    String consoleOutput = outputStream.toString();

    int expectedNumberOfQuestions = 1;
    assertTrue(consoleOutput.contains("How many questions would you like to practice?"));
    assertEquals(expectedNumberOfQuestions, QuestionViewer.numberOfQ);
  }

  /**
   * Tests the askNumberOfQuestions method
   */
  @Test
  public void testAskNumberOfQuestions2() {
    String userInput = "5";
    QuestionViewer.numberOfQ = 2;

    ByteArrayInputStream inputStream = new ByteArrayInputStream((userInput + "\n").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);
    QuestionViewer.filePath = "sample.sr";
    QuestionViewer.askNumberOfQuestions();
    System.out.flush();
    PrintStream originalOut = System.out;
    System.setOut(originalOut);
    String consoleOutput = outputStream.toString();

    int expectedNumberOfQuestions = 2;
    assertTrue(consoleOutput.contains("How many questions would you like to practice?"));
    assertEquals(expectedNumberOfQuestions, QuestionViewer.numberOfQ);
  }

  /**
   * Tests the startStudying method
   */
  @Test
  public void testStartStudying() throws FileNotFoundException {
    QuestionViewer.numberOfQ = 3;
    QuestionViewer.filePath = "studentFile.sr";
    QuestionViewer.file = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]H3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));

    ByteArrayInputStream inputStream = new ByteArrayInputStream(("1\n3\n4").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);
    QuestionViewer.startStudying();
    PrintStream originalOut = System.out;
    System.out.flush();
    System.setOut(originalOut);

    String consoleOutput = outputStream.toString();
    System.out.println(consoleOutput);

    assertTrue(consoleOutput.contains("What is the capital of Canada?"));
    assertTrue(consoleOutput.contains("Enter '1' if it's an easy question, '2' if it's hard, "
        + "'3' to see the answer, and '4' to end the study session."));
    assertTrue(consoleOutput.contains("What is the largest river in Africa?"));
    assertTrue(consoleOutput.contains("You have exited the study session."));

  }

  /**
   * Tests the exception when calling startStudying
   */
  @Test
  public void testStartStudyingException() {
    QuestionViewer.numberOfQ = 3;
    QuestionViewer.filePath = "studentFile.sr";
    QuestionViewer.file = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]H3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));

    ByteArrayInputStream inputStream = new ByteArrayInputStream(("1\n5\n4").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);

    System.setOut(printStream);
    PrintStream originalOut = System.out;
    try {
      QuestionViewer.startStudying();
    } catch (Exception e) {
      assertEquals("Not a valid option", e.getMessage());
    }

    System.out.flush();
    System.setOut(originalOut);

  }

  /**
   * Tests the startStudying method
   */
  @Test
  public void testStartStudyingFinalStats() throws FileNotFoundException {
    QuestionViewer.numberOfQ = 3;
    QuestionViewer.filePath = "studentFile.sr";
    QuestionViewer.file = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]H3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));

    ByteArrayInputStream inputStream = new ByteArrayInputStream(("1\n3\n3").getBytes());
    System.setIn(inputStream);

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);
    QuestionViewer.startStudying();
    PrintStream originalOut = System.out;
    System.out.flush();
    System.setOut(originalOut);

    String consoleOutput = outputStream.toString();

    assertTrue(consoleOutput.contains("What is the capital of Canada?"));
    assertTrue(consoleOutput.contains("Enter '1' if it's an easy question, '2' if it's hard, "
        + "'3' to see the answer, and '4' to end the study session."));
    assertTrue(consoleOutput.contains("What is the largest river in Africa?"));

  }

  /**
   * Tests the writeSrFile method
   */
  @Test
  public void testWriteSrFile() {
    String srFilePath = "src/test/pa01test";

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream originalOut = System.out;
    System.setOut(new PrintStream(outputStream));

    QuestionViewer.writeSrFile(srFilePath);

    System.setOut(originalOut);

    String capturedOutput = outputStream.toString().trim();


    String expectedOutput = "";
    File srFile = new File(srFilePath);
    assertTrue(srFile.exists(), "");

    assertEquals(expectedOutput, capturedOutput, "Unexpected output message");
  }
}
