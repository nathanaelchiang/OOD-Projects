package cs3500.pa02;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 * Tests the FileProcessor class
 */
class FileProcessorTest {
  /**
   * Tests the sortsFile method
   */
  @Test
  public void testSortsFile() {
    FileProcessor fileProcessor = new FileProcessor();
    String notesRoot = "src/test/pa01test";
    String orderingFlagName = "filename";
    ArrayList<File> orderedList = new ArrayList<>();
    orderedList = fileProcessor.sortsFile(notesRoot, orderingFlagName);
    ArrayList<String> stringList = new ArrayList<>();
    for (File file : orderedList) {
      stringList.add(file.getPath());
    }
    ArrayList<String> expectedList = new ArrayList<>(
        Arrays.asList("src/test/pa01test/arrays.md", "src/test/pa01test/connectLines.md",
            "src/test/pa01test/testwritesr.md", "src/test/pa01test/vectors.md"));
    assertEquals(expectedList, stringList);

  }

  /**
   * Tests the sortsFile exception
   */
  @Test
  public void testSortsFileException() {
    FileProcessor fileProcessor = new FileProcessor();
    String notesRoot = "src/test/pa01tes";
    String orderingFlagName = "filename";
    try {
      fileProcessor.sortsFile(notesRoot, orderingFlagName);
    } catch (Exception e) {
      assertEquals("An error occurred during file processing", e.getMessage());
    }
  }
}