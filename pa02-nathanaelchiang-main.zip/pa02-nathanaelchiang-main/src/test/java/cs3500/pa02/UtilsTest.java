package cs3500.pa02;



import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 * Tests the Utils class
 */
public class UtilsTest {

  /**
   * Tests the readSrFile method
   */
  @Test
  public void testReadSrFile() {
    String filePath = "sample.sr";
    ArrayList<String> expectedLines = new ArrayList<>(
        Arrays.asList(
            "[[What is the chemical symbol for hydrogen?:::The symbol is H.]]H1",
            "[[What is the chemical symbol for oxygen?:::The symbol is O.]]E2"
        )
    );

    ArrayList<String> lines = Utils.readSrFile(filePath);

    assertEquals(expectedLines, lines);
  }

  /**
   * Tests the ReadSrFile exception
   */
  @Test
  public void testReadSrFileException() {
    String filePath = "sample1.md";
    ArrayList<String> expectedLines = new ArrayList<>(
        Arrays.asList(
            "[[What is the chemical symbol for hydrogen?:::The symbol is H.]]H1",
            "[[What is the chemical symbol for oxygen?:::The symbol is O.]]H2"
        )
    );

    try {
      Utils.readSrFile(filePath);
    } catch (Exception e) {
      assertEquals("Not a sr file.", e.getMessage());
    }
  }

  /**
   * Tests the addHardAndId method
   */
  @Test
  public void testAddHardAndId() {
    ArrayList<String> inputList = new ArrayList<>(
        Arrays.asList(
            "[[What is the chemical symbol for hydrogen?:::The symbol is H.]]",
            "[[What is the chemical symbol for oxygen?:::The symbol is O.]]"
        )
    );

    ArrayList<String> expectedList = new ArrayList<>(
        Arrays.asList(
            "[[What is the chemical symbol for hydrogen?:::The symbol is H.]]H1",
            "[[What is the chemical symbol for oxygen?:::The symbol is O.]]H2"
        )
    );
    ArrayList<String> result = Utils.addHardAndId(inputList);

    assertEquals(expectedList, result);
  }
}
