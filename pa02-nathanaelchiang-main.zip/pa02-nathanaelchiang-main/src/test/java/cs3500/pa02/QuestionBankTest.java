package cs3500.pa02;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 * Tests the QuestionBank class
 */
class QuestionBankTest {

  /**
   * Tests the assignQuestions method
   */
  @Test
  public void testAssignQuestions() {
    ArrayList<String> list = new ArrayList<>();
    list.add("[[What is the chemical symbol for hydrogen?:::The symbol is H.]]E1");
    list.add("[[What is the chemical symbol for oxygen?:::The symbol is O.]]H2");

    QuestionBank.hardQuestions = new ArrayList<>();
    QuestionBank.easyQuestions = new ArrayList<>();
    QuestionBank.assignQuestions(list);

    assertEquals(1, QuestionBank.easyQuestions.size());
    assertEquals(1, QuestionBank.hardQuestions.size());
    assertEquals("[[What is the chemical symbol for hydrogen?:::The symbol is H.]]E1",
        QuestionBank.easyQuestions.get(0));
    assertEquals("[[What is the chemical symbol for oxygen?:::The symbol is O.]]H2",
        QuestionBank.hardQuestions.get(0));

    assertEquals(list, QuestionBank.assignQuestions(list));
  }

  /**
   * Tests the generateQuestions method
   */
  @Test
  public void testGenerateQuestions() {
    QuestionBank.hardQuestions = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]H3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));
    QuestionBank.easyQuestions = new ArrayList<>(
        Arrays.asList("[[Which country is known as the Land of the Rising Sun?:::Japan.]]E2",
            "[[What is the tallest mountain in North America?:::The tallest mountain is Denali "
                + "(also known as Mount McKinley).]]E4",
            "[[What is the longest river in South America?:::"
                + "The longest river is the Amazon River.]]E6"));
    QuestionBank.generatedQuestions = new ArrayList<>();

    int value1 = 4;
    QuestionBank.generateQuestions(value1);
    assertEquals(value1, QuestionBank.generatedQuestions.size());

    int value2 = 8;
    QuestionBank.generateQuestions(value2);
    assertEquals(QuestionBank.hardQuestions.size() + QuestionBank.easyQuestions.size(),
        QuestionBank.generatedQuestions.size());

    int value3 = 2;
    QuestionBank.generateQuestions(value3);
    assertEquals(value3, QuestionBank.generatedQuestions.size());

  }
}