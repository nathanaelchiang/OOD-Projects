package cs3500.pa02;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 * Tests the QuestionControllerImpl class
 */
class QuestionControllerImplTest {

  /**
   * Tests the seQuestionAndAnswer method
   */
  @Test
  public void testSetQuestionAndAnswer() {
    String line = "[[What is the capital of Canada?:::The capital is Ottawa.]]H1";
    QuestionControllerImpl.setQuestionAndAnswer(line);
    assertEquals("What is the capital of Canada?", QuestionControllerImpl.currentQuestion);
    assertEquals("The capital is Ottawa.", QuestionControllerImpl.currentAnswer);
  }

  /**
   * Tests the getCurrentQuestion method
   */
  @Test
  public void testGetCurrentQuestion() {
    ArrayList<String> list = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]H3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));
    assertEquals("What is the capital of Canada?",
        QuestionControllerImpl.getCurrentQuestion(list, 0));
  }

  /**
   * Tests the fixDifficulty method
   */
  @Test
  public void testFixDifficulty() {
    ArrayList<String> list = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]E3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));
    QuestionControllerImpl.fixDifficulty(list, 1, 1);
    assertEquals("[[What is the capital of Canada?:::The capital is Ottawa.]]E1",
        list.get(0));
    QuestionControllerImpl.fixDifficulty(list, 2, 15);
    assertEquals("[[What is the largest river in Africa?:::"
        + "The largest river is the Nile River.]]E3", list.get(1));
    QuestionControllerImpl.fixDifficulty(list, 2, -1);
    assertEquals("[[What is the largest river in Africa?:::"
        + "The largest river is the Nile River.]]E3", list.get(1));
    QuestionControllerImpl.fixDifficulty(list, 2, 2);
    assertEquals("[[What is the largest river in Africa?:::"
        + "The largest river is the Nile River.]]H3", list.get(1));
    QuestionControllerImpl.fixDifficulty(list, 3, 2);
    assertEquals("[[What is the largest river in Africa?:::"
        + "The largest river is the Nile River.]]H3", list.get(1));
  }

  /**
   * Tests the getStats method
   */
  @Test
  public void testGetStats() {
    QuestionControllerImpl.qToEasyCount = 1;
    QuestionControllerImpl.qToHardCount = 2;
    QuestionControllerImpl.totalQuestionCount = 3;
    QuestionBank.easyQuestions = new ArrayList<>(
        Arrays.asList(
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]E3"));
    QuestionBank.hardQuestions = new ArrayList<>(
        Arrays.asList(
            "[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(outputStream);
    System.setOut(printStream);

    ArrayList<String> list1 = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]E3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));

    QuestionControllerImpl.getStats(list1);
    PrintStream originalOut = System.out;
    System.out.flush();
    System.setOut(originalOut);

    String actualStats = outputStream.toString();

    String expectedStats = "You answered 3 total question(s).\n"
        + "2 question(s) have turned from easy to hard.\n"
        + "1 question(s) have turned from hard to easy.\n"
        + "There are 4 hard question(s) in your question bank.\n"
        + "There are 2 easy question(s) in your question bank.\n";

    assertEquals(expectedStats, actualStats);
  }

  /**
   * Tests the afterPress method
   */
  @Test
  public void testAfterPress() {
    ArrayList<String> list = new ArrayList<>(
        Arrays.asList("[[What is the capital of Canada?:::The capital is Ottawa.]]H1",
            "[[What is the largest river in Africa?:::The largest river is the Nile River.]]E3",
            "[[Which continent is the driest inhabited continent on Earth?:::Australia.]]H5"));
    QuestionControllerImpl.afterPress(list, 1, 2);
    assertEquals("[[What is the capital of Canada?:::The capital is Ottawa.]]H1", list.get(0));
    QuestionControllerImpl.afterPress(list, 2, 1);
    assertEquals("[[What is the capital of Canada?:::The capital is Ottawa.]]H1", list.get(0));
    QuestionControllerImpl.afterPress(list, 3, 1);
    assertEquals("[[What is the capital of Canada?:::The capital is Ottawa.]]H1", list.get(0));
    try {
      QuestionControllerImpl.afterPress(list, 5, 1);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}