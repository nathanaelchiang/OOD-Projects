package cs3500.pa02;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 * Tests the OrderingFiles class
 */
class OrderingFilesTest {
  static final String PA01_DIRECTORY = "src/test/pa01test";

  /**
   * Tests the class that orders the files
   */
  @Test
  public void testGetFiles() {
    Flag flag = Flag.FILENAME;
    ArrayList<String> listNames = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/arrays.md",
        PA01_DIRECTORY + "/vectors.md"
    ));
    ArrayList<String> listNames1 = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/vectors.md",
        PA01_DIRECTORY + "/arrays.md"
    ));
    Flag invalidFlag = Flag.FILENAME;
    ArrayList<String> listNamesInvalid = new ArrayList<>();

    ArrayList<File> orderedFiles = OrderingFiles.orderFiles(flag, listNames);
    ArrayList<File> orderedFiles1 = OrderingFiles.orderFiles(flag, listNames);
    ArrayList<File> orderedFiles2 = OrderingFiles.orderFiles(invalidFlag, listNamesInvalid);
    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles.get(0).getPath());
    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles.get(1).getPath());
    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles1.get(0).getPath());
    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles1.get(1).getPath());
    try {
      orderedFiles1.get(1).getPath();
    } catch (NullPointerException e) {
      fail();
    }
  }

  /**
   * Tests the files ordered by time last modified.
   */
  @Test
  public void testOrderFilesByCreated() {
    Flag flag = Flag.CREATED;
    ArrayList<String> listNames = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/arrays.md",
        PA01_DIRECTORY + "/vectors.md"
    ));

    File arraysFile = new File(PA01_DIRECTORY + "/arrays.md");
    File vectorsFile = new File(PA01_DIRECTORY + "/vectors.md");


    ArrayList<File> orderedFiles = OrderingFiles.orderFiles(flag, listNames);
    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles.get(0).getPath());
    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles.get(1).getPath());
  }

  /**
   * Tests the exception in the ordering files function
   */
  @Test
  public void testOrderFilesByCreatedException() {
    Flag flag = Flag.CREATED;
    ArrayList<String> listNames = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/arrays.md",
        PA01_DIRECTORY + "/vectors.md"
    ));

    File arraysFile = new File(PA01_DIRECTORY + "/array.md");

    try {
      OrderingFiles.getFileCreationTime(arraysFile);
    } catch (Exception e) {
      assertEquals("No creation time given.", e.getMessage());
    }
  }
}

