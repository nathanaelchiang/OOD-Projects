package cs3500.pa02;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Displays the questions
 */
public class QuestionViewer {
  public static String filePath;
  public static int numberOfQ;
  public static ArrayList<String> file = new ArrayList<>();

  /**
   * Gets and checks if the sr file is valid
   */
  public static void checkSrFile() {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter the path of the sr file");
    filePath = scanner.nextLine();
    if (!filePath.endsWith(".sr")) {
      throw new InputMismatchException("Not a sr file.");
    }
  }

  /**
   * Ask how many number of questions to answer
   */
  public static void askNumberOfQuestions() {
    Scanner scanner = new Scanner(System.in);
    System.out.println("How many questions would you like to practice?");
    numberOfQ = Integer.parseInt(scanner.nextLine());
    file = Utils.readSrFile(filePath);
    if (numberOfQ > file.size()) {
      numberOfQ = file.size();
    }
  }

  /**
   * Starts the study session
   *
   * @throws FileNotFoundException if the file given is not valid
   */
  public static void startStudying() throws FileNotFoundException {
    Scanner scanner = new Scanner(System.in);
    ArrayList<String> updatedFile = Utils.addHardAndId(file);
    for (int i = 0; i < numberOfQ; i++) {
      System.out.println(QuestionControllerImpl.getCurrentQuestion(updatedFile, i));
      System.out.println("Enter '1' if it's an easy question, '2' if it's hard, "
          + "'3' to see the answer, and '4' to end the study session.");
      int answer = Integer.parseInt(scanner.nextLine());
      if (!(answer == 1 || answer == 2 || answer == 3 || answer == 4)) {
        throw new InputMismatchException("Not a valid option");
      }
      if (answer == 4) {
        System.out.println("You have exited the study session.");
        QuestionControllerImpl.getStats(updatedFile);
        Processor.writeStudyGuide(filePath, updatedFile);
        break;
      }
      QuestionControllerImpl.afterPress(updatedFile, answer, i + 1);
      if (i == numberOfQ - 1) {
        QuestionControllerImpl.getStats(updatedFile);
        Processor.writeStudyGuide(filePath, updatedFile);
      }
    }
  }

  /**
   * Writes the sr file after the session
   *
   * @param srFilePath The path of sr file
   */
  public static void writeSrFile(String srFilePath) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(srFilePath))) {
      for (String line : Processor.srLines) {
        writer.write(line);
        writer.newLine();
      }
      System.out.println("SR file created.");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}

