package cs3500.pa02;

import java.util.ArrayList;

/**
 * Controller for the study session
 */
public class QuestionControllerImpl {

  public static String currentQuestion;
  public static String currentAnswer;
  public static int qToHardCount;
  public static int qToEasyCount;
  public static int totalQuestionCount;

  /**
   * Gets the current question that needs to be asked
   *
   * @param list  the list of questions
   * @param value the index of the question to get
   * @return the current question to ask
   */
  public static String getCurrentQuestion(ArrayList<String> list, int value) {
    String line = list.get(value);
    setQuestionAndAnswer(line);
    return currentQuestion;
  }

  /**
   * Sets the current question and answer
   *
   * @param line the line that has the question and answer
   */
  public static void setQuestionAndAnswer(String line) {
    int questionStart = line.indexOf("[[");
    int questionEnd = line.indexOf(":::");
    currentQuestion = line.substring(questionStart + 2, questionEnd);
    int answerStart = questionEnd + 3;
    int answerEnd = line.indexOf("]]");
    currentAnswer = line.substring(answerStart, answerEnd);
  }

  /**
   * What happens after the user inputs a number
   *
   * @param list  The list of questions
   * @param value the input number
   * @param id    the id of the question
   */
  public static void afterPress(ArrayList<String> list, int value, int id) {
    if (value == 1) {
      fixDifficulty(list, 1, id);
      totalQuestionCount = totalQuestionCount + 1;
    } else if (value == 2) {
      fixDifficulty(list, 2, id);
      totalQuestionCount = totalQuestionCount + 1;
    } else if (value == 3) {
      System.out.println(currentAnswer);
      fixDifficulty(list, 2, id);
      totalQuestionCount = totalQuestionCount + 1;
    } else {
      throw new IllegalArgumentException("Invalid input");
    }
  }

  /**
   * Fixes the difficulty of the question
   *
   * @param list       the list of questions and answers
   * @param difficulty the difficulty (1 is easy, 2 is hard)
   * @param lineNumber the line number in the list
   */
  public static void fixDifficulty(ArrayList<String> list, int difficulty, int lineNumber) {
    int index = lineNumber - 1;
    if (index < 0 || index >= list.size()) {
      return;
    }
    String line = list.get(index);
    int lineLength = line.length();

    if (lineLength >= 2) {
      int charIndex = line.indexOf("]]") + 2;
      if (difficulty == 1) {
        if (line.charAt(charIndex) != 'E') {
          qToEasyCount = qToEasyCount + 1;
          String newLine =
              line.substring(0, charIndex) + "E" + line.substring(charIndex + 1);
          list.set(index, newLine);
        }
      } else if (difficulty == 2) {
        if (line.charAt(charIndex) != 'H') {
          qToHardCount = qToHardCount + 1;
          String newLine =
              line.substring(0, charIndex) + "H" + line.substring(charIndex + 1);
          list.set(index, newLine);
        }
      }
    }
  }


  /**
   * Gets and calculates the stats shown at the end of the session
   *
   * @param list list of questions
   */
  public static void getStats(ArrayList<String> list) {
    System.out.println("You answered " + totalQuestionCount + " total question(s).");
    System.out.println(qToHardCount + " question(s) have turned from easy to hard.");
    System.out.println(qToEasyCount + " question(s) have turned from hard to easy.");
    QuestionBank.assignQuestions(list);
    System.out.println("There are " + QuestionBank.hardQuestions.size()
        + " hard question(s) in your question bank.");
    System.out.println("There are " + QuestionBank.easyQuestions.size()
        + " easy question(s) in your question bank.");
  }


}
