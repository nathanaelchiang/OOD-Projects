package cs3500.pa02;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * The Utils class, includes reading and adding the ids
 */
public class Utils {
  /**
   * Reads the sr file
   *
   * @param filePath the given file path for the sr file
   * @return the lines in the sr file
   */
  public static ArrayList<String> readSrFile(String filePath) {
    ArrayList<String> lines = new ArrayList<>();
    try {
      lines.addAll(Files.readAllLines(Path.of(filePath)));
    } catch (IOException e) {
      e.printStackTrace();
    }
    return lines;
  }

  /**
   * Assigns every question as hard initially and adds a id to each question
   *
   * @param list list of the questions
   * @return the list after it is assigned its difficulty and id
   */
  public static ArrayList<String> addHardAndId(ArrayList<String> list) {
    for (int i = 0; i < list.size(); i++) {
      String line = list.get(i);
      if (line.endsWith("]]")) {
        line = line.concat("H");
        line = line.concat(Integer.toString(i + 1));
        list.set(i, line);
      }
    }
    return list;
  }
}
