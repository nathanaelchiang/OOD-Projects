package cs3500.pa02;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This is the main driver of this project.
 */
public class Driver {
  /**
   * Project empty points
   *
   * @param args inputs
   * @throws IOException for errors such as invalid files or invalid args
   */
  public static void main(String[] args) throws IOException {
    if (args.length == 0) {
      System.out.println("Welcome to the Study Session Mode");
      QuestionViewer.checkSrFile();
      QuestionViewer.askNumberOfQuestions();
      QuestionViewer.startStudying();
    } else if (args.length == 3) {
      System.out.println("Hello from PA01 Template Repo");
      String notesRoot = args[0];
      String orderingFlagName = args[1];
      String outputFilePath = args[2];
      FileProcessor primary = new FileProcessor();
      ArrayList<File> orderedList = primary.sortsFile(notesRoot, orderingFlagName);
      primary.formatAndGenerateFile(orderedList, outputFilePath);
    }
  }
}
