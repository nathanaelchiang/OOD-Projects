package cs3500.pa02;

import java.util.ArrayList;
import java.util.Random;

/**
 * The model of the study session and stores the questions
 */
public class QuestionBank {
  public static ArrayList<String> easyQuestions = new ArrayList<>();
  public static ArrayList<String> hardQuestions = new ArrayList<>();

  public static ArrayList<String> generatedQuestions = new ArrayList<>();

  /**
   * Assigns questions as hard or easy
   *
   * @param list the list of questions
   * @return list of assigned questions
   */
  public static ArrayList<String> assignQuestions(ArrayList<String> list) {
    for (int i = 0; i < list.size(); i++) {
      String line = list.get(i);
      int end = line.indexOf("]]");
      if (line.substring(end + 2, line.length() - 1).equals("E")) {
        easyQuestions.add(line);
      } else {
        hardQuestions.add(line);
      }
    }
    return list;
  }

  /**
   * Generates the questions based on the amount given
   *
   * @param value The number of questions to be generated
   * @return the generated questions
   */
  public static ArrayList<String> generateQuestions(int value) {
    Random random = new Random();
    generatedQuestions.clear();

    if (hardQuestions.size() + easyQuestions.size() >= value) {
      if (hardQuestions.size() >= value) {
        for (int i = 0; i < value; i++) {
          int randomIndex = random.nextInt(hardQuestions.size());
          generatedQuestions.add(hardQuestions.get(randomIndex));
        }
      } else {
        generatedQuestions.addAll(hardQuestions);

        int remainingCount = value - hardQuestions.size();
        for (int i = 0; i < remainingCount; i++) {
          int randomIndex = random.nextInt(easyQuestions.size());
          generatedQuestions.add(easyQuestions.get(randomIndex));
        }
      }
    } else {
      generatedQuestions.addAll(hardQuestions);
      generatedQuestions.addAll(easyQuestions);
    }
    return generatedQuestions;
  }
}
