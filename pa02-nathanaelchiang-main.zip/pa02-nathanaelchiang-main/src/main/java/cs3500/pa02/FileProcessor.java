package cs3500.pa02;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * Processes the files.
 */
public class FileProcessor {
  /**
   * Sorts the files
   *
   * @param notesRoot folder including the md files
   * @param orderingFlagName flag name
   * @return list of files that are sorted
   */
  public ArrayList<File> sortsFile(String notesRoot, String orderingFlagName) {
    try {
      // 2. Get all markdown files
      System.out.print("Walking the FileSystem...");
      Path startingDirectory = Path.of(notesRoot);
      FileVisitor pf = new FileVisitor();
      Files.walkFileTree(startingDirectory, pf);

      // 3. Sorts all files
      ArrayList<File> orderedList = new ArrayList<>();
      Flag flagName;
      if (orderingFlagName.equals("filename")) {
        flagName = Flag.FILENAME;
      } else if (orderingFlagName.equals("created")) {
        flagName = Flag.CREATED;
      } else if (orderingFlagName.equals("modified")) {
        flagName = Flag.MODIFIED;
      } else {
        throw new IllegalArgumentException("Invalid flag.");
      }

      orderedList = OrderingFiles.orderFiles(flagName, pf.getList());

      System.out.println(" Test" + orderedList);
      return orderedList;

    } catch (IOException e) {
      e.printStackTrace();
      System.out.println("An error occurred during file processing: " + e.getMessage());
    }
    return null;
  }

  /**
   * Formats and generates the file
   *
   * @param orderedList a list of files to format
   * @param outputFilePath the output file path
   * @throws FileNotFoundException if the file can't be found
   */
  public void formatAndGenerateFile(ArrayList<File> orderedList, String outputFilePath)
      throws FileNotFoundException {

    // 4. Formats the output file
    ArrayList<String> fileNames = new ArrayList<>();
    for (File filePath : orderedList) {
      fileNames.add(filePath.getPath());
      System.out.println(filePath.getName());
    }

    // 5. Generates the output file
    Processor.generateStudyGuide(fileNames, outputFilePath);
    System.out.println("Study guide printed.");

    String srFilePath = outputFilePath.substring(0, outputFilePath.length() - 3);
    srFilePath = srFilePath.concat(".sr");

    QuestionViewer.writeSrFile(srFilePath);

  }

}
