package cs3500.pa02;

/**
 * Represents the three options for a flag
 */
public enum Flag {
    FILENAME,
    CREATED,
    MODIFIED,

}
