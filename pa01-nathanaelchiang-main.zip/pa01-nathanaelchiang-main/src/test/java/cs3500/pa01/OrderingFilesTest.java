package cs3500.pa01;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

class OrderingFilesTest {
  static final String PA01_DIRECTORY = "src/test/resources/pa01test";

  /**
   * Tests the class that orders the files
   */
  @Test
  public void testGetFiles() {
    OrderingFiles.Flag flag = OrderingFiles.Flag.FILENAME;
    ArrayList<String> listNames = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/arrays.md",
        PA01_DIRECTORY + "/vectors.md"
    ));
    ArrayList<String> listNames1 = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/vectors.md",
        PA01_DIRECTORY + "/arrays.md"
    ));
    OrderingFiles.Flag invalidFlag = OrderingFiles.Flag.FILENAME;
    ArrayList<String> listNamesInvalid = new ArrayList<>();

    ArrayList<File> orderedFiles = OrderingFiles.orderFiles(flag, listNames);
    ArrayList<File> orderedFiles1 = OrderingFiles.orderFiles(flag, listNames);
    ArrayList<File> orderedFiles2 = OrderingFiles.orderFiles(invalidFlag, listNamesInvalid);
    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles.get(0).getPath());
    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles.get(1).getPath());
    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles1.get(0).getPath());
    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles1.get(1).getPath());
    try {
      orderedFiles1.get(1).getPath();
    } catch (NullPointerException e) {
      fail();
    }
  }

  //  /**
  //   * Tests the files sorted by time created
  //   */
  //  @Test
  //  public void testOrderFilesByCreated() {
  //    OrderingFiles.Flag flag = OrderingFiles.Flag.CREATED;
  //    ArrayList<String> listNames = new ArrayList<>(Arrays.asList(
  //        PA01_DIRECTORY + "/arrays.md",
  //        PA01_DIRECTORY + "/vectors.md"
  //    ));
  //
  //    File arraysFile = new File(PA01_DIRECTORY + "/arrays.md");
  //    File vectorsFile = new File(PA01_DIRECTORY + "/vectors.md");
  //
  //    FileTime knownCreationTime = FileTime.from(Instant.parse("2023-05-14T12:00:00Z"));
  //    FileTime knownCreationTime1 = FileTime.from(Instant.parse("2023-06-14T12:00:00Z"));
  //    MarkdownFile mdf = new MarkdownFile(knownCreationTime);
  //
  //    ArrayList<File> orderedFiles = OrderingFiles.getFiles(flag, listNames);
  //    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles.get(0).getPath());
  //    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles.get(1).getPath());
  //  }


  /**
   * Tests the files ordered by time last modified.
   */
  @Test
  public void testOrderFilesByModified() {
    OrderingFiles.Flag flag = OrderingFiles.Flag.MODIFIED;
    ArrayList<String> listNames = new ArrayList<>(Arrays.asList(
        PA01_DIRECTORY + "/arrays.md",
        PA01_DIRECTORY + "/vectors.md"
    ));

    File arraysFile = new File(PA01_DIRECTORY + "/arrays.md");
    File vectorsFile = new File(PA01_DIRECTORY + "/vectors.md");


    ArrayList<File> orderedFiles = OrderingFiles.orderFiles(flag, listNames);
    assertEquals(PA01_DIRECTORY + "/arrays.md", orderedFiles.get(0).getPath());
    assertEquals(PA01_DIRECTORY + "/vectors.md", orderedFiles.get(1).getPath());
  }


}

