package cs3500.pa01;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;

class DriverTest {

  @Test
  public void testMain() throws IOException {
    String notesRoot =
        "Users/nathanaelchiang/Desktop/cs3500/pa01-nathanaelchiang/src/test/pa01test";
    String filename = "filename";
    String created = "created";
    String modified = "modified";
    String outputFilePath =
        "Users/nathanaelchiang/Desktop/cs3500/pa01-nathanaelchiang/src/test/output/output.md";
    String[] args = {notesRoot, filename, outputFilePath};
    String[] args1 = {notesRoot, created, outputFilePath};
    String[] args2 = {notesRoot, modified, outputFilePath};
    Driver.main(args);
    Driver.main(args1);
    Driver.main(args2);

  }

  @Test
  public void testGetNames() throws IOException {
    String notesRoot =
        "src/test/pa01test";
    String invalidFlag = "filename";
    String outputFilePath =
        "src/test/output/output.md";
    String[] args = {notesRoot, invalidFlag, outputFilePath};
    Driver.main(args);

    Path startingDirectory = Path.of(notesRoot);
    FileVisitor pf = new FileVisitor();
    Files.walkFileTree(startingDirectory, pf);
    ArrayList<File> orderedList = new ArrayList<File>();
    ArrayList<String> fileNames = new ArrayList<>();
    for (File filePath : orderedList) {
      fileNames.add(filePath.getName());
    }
    Processor.generateStudyGuide(fileNames, outputFilePath);

    System.out.println("Study guide printed.");

  }

  @Test
  public void testException() {
    String notesRoot =
        "src/test/pa01test";
    String invalidFlag = "invalid";
    String outputFilePath =
        "src/test/output/output.md";
    String[] args = {notesRoot, invalidFlag, outputFilePath};
    try {
      Driver.main(args);
    } catch (IllegalArgumentException e) {
      System.out.println("Error");

    }

  }
}