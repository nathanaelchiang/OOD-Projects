package cs3500.pa01;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Processes the markdown files.
 */
public class Processor {
  /**
   * Generates the study guide.
   *
   * @param listNames the given list of name of files
   * @param outputPath the given outputPath for the file
   * @throws FileNotFoundException if the file is not found
   */
  public static void generateStudyGuide(ArrayList<String> listNames, String outputPath)
      throws FileNotFoundException {
    ArrayList<File> list = new ArrayList<>();
    for (String fileName : listNames) {
      File file = new File(fileName);
      list.add(file);
    }
    ArrayList<String> output = processFiles(list);

    writeStudyGuide(outputPath, output);
  }

  /**
   * Processes the given list of files into a list of strings.
   *
   * @param inputFiles the given list of files
   * @return the list of strings
   * @throws FileNotFoundException if the file is not found
   */
  public static ArrayList<String> processFiles(ArrayList<File> inputFiles)
      throws FileNotFoundException {
    ArrayList<String> output = new ArrayList<>();
    StringBuilder currentHeading = new StringBuilder();

    for (File inputFile : inputFiles) {
      for (String line : connectLines(inputFile)) {
        if (line.startsWith("#")) {
          output.add("");
          output.add(line);
        } else if (line.startsWith("-")) {
          String importantPhrase = getImportantPhrase(line);
          if (importantPhrase != null) {
            output.add(importantPhrase);
          }
        }
      }
    }

    return output;
  }

  /**
   * Connects two disconnected lines into one line.
   *
   * @param inputFile the given file
   * @return a file with the lines correctly connected
   * @throws FileNotFoundException if file is not found
   */
  public static ArrayList<String> connectLines(File inputFile) throws FileNotFoundException {
    ArrayList<String> output = new ArrayList<>();
    String preLine = "";

    Scanner scanner = new Scanner(inputFile);
    while (scanner.hasNextLine()) {
      String line = scanner.nextLine();

      if (line.startsWith("-")) {
        if (!preLine.isEmpty()) {
          output.add(preLine);
        }
        preLine = line;
      } else if (line.startsWith("#")) {
        if (!preLine.isEmpty()) {
          output.add(preLine);
        }
        output.add(line);
        preLine = "";
      } else if (line.isEmpty()) {
        if (!preLine.isEmpty()) {
          output.add(preLine);
        }
        output.add(line);
        preLine = "";
      } else {
        preLine += " " + line;
      }
    }
    scanner.close();

    if (!preLine.isEmpty()) {
      output.add(preLine);
    }
    return output;
  }

  /**
   * Writes the study guide given an output file name and a list of file names.
   *
   * @param outputFile the given string
   * @param output the list of names as strings
   * @throws FileNotFoundException if the file is not found
   */
  public static void writeStudyGuide(String outputFile, ArrayList<String> output)
      throws FileNotFoundException {
    PrintWriter writer = new PrintWriter(outputFile);
    for (String line : output) {
      writer.println(line);
    }
    writer.close();
  }

  /**
   * Gets the important phrases from a line.
   *
   * @param line the given string
   * @return the important phrase with a bullet point
   */
  public static String getImportantPhrase(String line) {
    int beginIndex = line.indexOf("[[");
    int endIndex = line.indexOf("]]", beginIndex);
    if (beginIndex >= 0 && endIndex >= 0) {
      return "- " + line.substring(beginIndex + 2, endIndex);
    } else {
      return null;
    }
  }
}
