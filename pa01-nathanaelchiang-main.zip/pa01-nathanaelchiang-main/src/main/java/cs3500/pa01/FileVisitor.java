package cs3500.pa01;

import static java.nio.file.FileVisitResult.CONTINUE;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;

/**
 * The FileVisitor class for the markdown files.
 */
public class FileVisitor implements java.nio.file.FileVisitor<Path> {

  private ArrayList<String> list = new ArrayList<String>();


  /**
   * Gets the list
   *
   * @return the list
   */
  public ArrayList<String> getList() {
    return list;
  }

  /**
   * called everytime the file system walker encounters a file.
   * If the fileName ends with ".md", we add it to a list.
   *
   * @param file
   *          a reference to the file
   * @param attr
   *          the file's basic attributes
   *
   * @return Continue processing
   */
  @Override
  public FileVisitResult visitFile(Path file, BasicFileAttributes attr) {

    String fileName = file.getFileName().toString();
    if (fileName.endsWith(".md")) {
      list.add(fileName);
    }

    return CONTINUE;
  }

  /**
   * What to do after processing all items in a directory
   *
   * @param dir
   *          a reference to the directory
   * @param exec
   *          {@code null} if the iteration of the directory completes without
   *          an error; otherwise the I/O exception that caused the iteration
   *          of the directory to complete prematurely
   *
   * @return Continue processing
   */
  @Override
  public FileVisitResult postVisitDirectory(Path dir, IOException exec) {
    System.out.format("Finishing Directory: %s%n", dir);
    return CONTINUE;
  }

  /**
   * What to do at the beginning of processing a directory
   *
   * @param dir
   *          a reference to the directory
   * @param attrs
   *          the directory's basic attributes
   *
   * @return Continue processing
   */
  @Override
  public FileVisitResult preVisitDirectory(Path dir,
                                           BasicFileAttributes attrs) throws IOException {
    System.out.format("Starting Directory: %s%n", dir);
    return CONTINUE;
  }

  /**
   * called when a file cannot be visited for some undetermined reason (perhaps
   * locked by another process or a access permissions issue)
   *
   * @param file
   *          a reference to the file
   * @param exc
   *          the I/O exception that prevented the file from being visited
   *
   * @return Continue processing
   */
  @Override
  public FileVisitResult visitFileFailed(Path file, IOException exc) {
    System.err.println(exc);
    return CONTINUE;
  }
}


