package cs3500.pa01;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * This is the main driver of this project.
 */
public class Driver {
  /**
   * Project entry point
   *
   * @param args - no command line args required
   */
  public static void main(String[] args) {

    try {
      // 1. Get input parameters
      System.out.println("Hello from PA01 Template Repo");
      String notesRoot = args[0];
      String orderingFlagName = args[1];

      // 2. Get all markdown files
      System.out.print("Walking the FileSystem...");
      Path startingDirectory = Path.of(notesRoot);
      FileVisitor pf = new FileVisitor();
      Files.walkFileTree(startingDirectory, pf);

      // 3. Sorts all files
      ArrayList<File> orderedList = new ArrayList<File>();
      OrderingFiles.Flag flagName;
      if (orderingFlagName.equals("filename")) {
        flagName = OrderingFiles.Flag.FILENAME;
      } else if (orderingFlagName.equals("created")) {
        flagName = OrderingFiles.Flag.CREATED;
      } else if (orderingFlagName.equals("modified")) {
        flagName = OrderingFiles.Flag.MODIFIED;
      } else {
        throw new IllegalArgumentException("Invalid flag.");
      }

      orderedList = OrderingFiles.orderFiles(flagName, pf.getList());
      System.out.println(orderedList);

      // 4. Formats the output file
      ArrayList<String> fileNames = new ArrayList<>();
      for (File filePath : orderedList) {
        fileNames.add(filePath.getName());
      }

      // 5. Generates the output file
      String outputFilePath = args[2];
      Processor.generateStudyGuide(fileNames, outputFilePath);

      System.out.println("Study guide printed.");

    } catch (IOException e) {
      e.printStackTrace();
      System.out.println("An error occurred during file processing: " + e.getMessage());
    }
  }
}

