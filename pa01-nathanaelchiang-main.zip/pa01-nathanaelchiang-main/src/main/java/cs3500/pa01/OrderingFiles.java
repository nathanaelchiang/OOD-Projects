package cs3500.pa01;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Represents a class that orders the files
 */
public class OrderingFiles {

  /**
   * Represents the three options for a flag
   */
  public enum Flag {
    FILENAME,
    CREATED,
    MODIFIED,
  }

  /**
   * Orders the files based on the given flag and list of name of files.
   *
   * @param flag the given flag
   * @param listNames the given list of name of files
   * @return the ordered list
   */
  public static ArrayList<File> orderFiles(Flag flag, ArrayList<String> listNames) {

    ArrayList<File> orderedList = new ArrayList<File>();


    for (String fileName : listNames) {
      File file = new File(fileName);
      orderedList.add(file);
    }


    switch (flag) {
      case FILENAME:
        Collections.sort(orderedList, Comparator.comparing(File::getName));
        break;
      case CREATED:
        Collections.sort(orderedList, Comparator.comparing(OrderingFiles::getFileCreationTime));
        break;
      case MODIFIED:
        Collections.sort(orderedList, Comparator.comparing(File::lastModified));
        break;
      default:
        System.out.println("Invalid flag");
        System.exit(1);
    }
    return orderedList;
  }

  /**
   * Gets the creation time of a file.
   *
   * @param file the given file
   * @return the creation time of the file
   */
  public static FileTime getFileCreationTime(File file) {
    try {
      Path filePath = file.toPath();
      BasicFileAttributes attributes = Files.readAttributes(filePath, BasicFileAttributes.class);
      return attributes.creationTime();
    } catch (IOException e) {
      e.printStackTrace();
      throw new IllegalArgumentException("No creation time given.");
    }

  }
}

