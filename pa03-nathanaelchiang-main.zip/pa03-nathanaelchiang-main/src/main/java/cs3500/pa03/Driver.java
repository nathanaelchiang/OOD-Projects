package cs3500.pa03;

/**
 * This is the main driver of this project.
 */
public class Driver {
  /**
   * Project entry point
   *
   * @param args - no command line args required
   */
  public static void main(String[] args) {
    System.out.println("Hello from Battle Salvo - PA03 Template Repo");
    ViewerConsole test = new ViewerConsole();
    test.getDimension();
    test.fleetSelection();
    while (test.displayWinner() == 2) {
      test.enterShots();
      test.takeShots();
    }
  }
}